package email_validator;


@SuppressWarnings("serial")
public class MisMatchException extends Exception {

	public MisMatchException(String message) {
		super(message);
	}
}
